// This page is now handled by app/[lang]/object/[id]/page.tsx dew w
export default function Page() {
  return null;
}