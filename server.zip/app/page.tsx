// This page is now handled by app/[lang]/page.tsx
// Middleware redirects root requests to /[default-locale]
export default function Page() {
  return null;
}